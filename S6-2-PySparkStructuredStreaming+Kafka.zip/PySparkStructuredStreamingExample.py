# Prior to running this application
# Create a directory named "sparkstreaming" in local file system home directory i.e. /home/hadoop
# You can use the command
# mkdir /home/hadoop/sparkstreaming
# This is the directory for the streaming data
# Run our pyspark structured streaming application using the command
# spark-submit --master local[*] PySparkStructuredStreamingExample.py 2>/dev/null
# It will start monitoring the directory for streaming data
# To simulate streaming data we can copy or move the files data?.csv one by one to the above directory every few seconds from the second terminal
# We can use the command below for the first file and so on.
# cp data1.csv /home/hadoop/sparkstreaming
# Every time a new file is appears in the above directory, our application's groupby operation will start and the result will be displayed

#Structured Streaming Example

# Import the necessary classes
import pyspark
from pyspark.sql import SparkSession

from pyspark.sql.functions import *
from pyspark.sql.types import *

# create sparksession
spark = SparkSession.builder.appName("StructStream").getOrCreate()

# creating Schema
# structured Streaming proccesing always requires the specification of a schema for the data in the stream
schema = StructType([StructField('emp_id', IntegerType(), True),
                   StructField('emp_name', StringType(), True),
                   StructField('job_name', StringType(), True),
                   StructField('manager_id', IntegerType(), True),
                   StructField('salary', DoubleType(), True),
                   StructField('dept_name', StringType(), True)])

# creating Streaming Dataframe that would read the data from a given folder

employee = spark.readStream.schema(schema).option("header", True).option("sep", ",").csv("file:///home/hadoop/sparkstreaming/")

# query to find the total count of employees in a particular profession
employee.groupBy("job_name").count().writeStream.format('console').outputMode('complete').start().awaitTermination()

# Now you will notice the groupby operation is run by spark on the existing data and result gets displayed

# The next file from data?.csv gets can be copied to the above directory
# The groupby computation will get started again by spark structured streaming and the result including the previous data is displayed again.

# We can copy or transfer the other data csv files one by one with a gap of a few seconds.
# Each time it transfers a file, the stream is read and the computation is performed.
# Since we specified output mode as complete the complete data is taken for the computation i.e. the group by aggregation.
