# Before running Stock Price Alert application, run this kafka producer.
# You can use the command $ python Stock_Price_KafkaProducer.py
# Make sure the file stock_stream_data.csv is available in the same directory.
# The producer reads the file stock_stream_data.csv and publishes 1000 lines of the file at a time to the specified topic at the intervals of 2 seconds.
# This forms our streaming data which our alert application reads as soon as the data is generated and displays the alert.

# Make sure to install kafka-python library using the command: pip install kafka-python

from kafka import KafkaProducer
from kafka.errors import KafkaError
import time

# Create KafkaProducer object
producer = KafkaProducer(bootstrap_servers=['localhost:9092'])

# Publish each line from the given file to the topic
# If the topic specified below is absent, then it will be created.
# If it is present then it will be used for pubishing the data

with open('stock_stream_data.csv', 'r') as file:
    count = 0
    while count <= 1000:
        line = file.readline()
        if not line:
            producer.flush()
            print("Flushed last records")
            break  # End of file
        # Process each 'line' here
        if len(line.strip())>0:
            producer.send('stock-topic', line.strip().encode('utf-8'))
            # Alternatively the following syntax can also be used
            # producer.send('stock-topic', bytes(line.strip(),'utf-8'))
            count += 1
            if count == 1000:
                count = 0
                time.sleep(2)

print("Closing the data stream")
