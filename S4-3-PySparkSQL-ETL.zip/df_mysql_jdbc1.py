# Check for the JDBC driver using the command below,
$ ls -l /usr/lib/spark/jars/mariadb-connector-java.jar

# Run pyspark shell using the command below
$ pyspark --jars /usr/lib/spark/jars/mariadb-connector-java.jar --master local[*]

# Run the following code line by line in pyspark shell

>>> jdbcDF1 = spark.read.format("jdbc").option("url", "<RDS End Point>").option("driver", "org.mariadb.jdbc.Driver").option("dbtable", "trgdb.cctab").option("user", "root").option("password", "Root1234$").load()

# For example:
# jdbcDF1 = spark.read.format("jdbc").option("url", "jdbc:mysql://database-1.cujgmw0ksjco.us-east-1.rds.amazonaws.com").option("driver", "org.mariadb.jdbc.Driver").option("dbtable", "trgdb.cctab").option("user", "root").option("password", "Root1234$").load()

>>> jdbcDF1.printSchema()

>>> jdbcDF1.count()

>>> jdbcDF1.show()

>>> jdbcDF2 = spark.read.jdbc("jdbc:mysql://<RDS End Point>", "trgdb.tkttbl", properties={"user": "root", "password": "Root1234$"})

# For example:
# jdbcDF2 = spark.read.jdbc("jdbc:mysql://database-1.cujgmw0ksjco.us-east-1.rds.amazonaws.com/", "trgdb.tkttbl", properties={"user": "root", "password": "Root1234$"})

>>> jdbcDF2.printSchema()

>>> jdbcDF2.count()

>>> jdbcDF2.show()
