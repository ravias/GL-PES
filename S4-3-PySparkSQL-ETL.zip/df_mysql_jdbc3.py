# Run the following pyspark application using the command below.
# spark-submit --master local[*] df_mysql_jdbc3.py

import pyspark

from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("PySpark SQL from RDBMS - Example").getOrCreate()

spark = SparkSession.builder.appName("PySpark SQL from RDBMS - Example").config("spark.jars", "/usr/lib/spark/jars/mariadb-connector-java.jar").getOrCreate()

jdbcDF1 = spark.read.format("jdbc").option("url", "<RDS End Point>").option("driver", "org.mariadb.jdbc.Driver").option("dbtable", "trgdb.cctab").option("user", "root").option("password", "Root1234$").load()

# For example:
# jdbcDF1 = spark.read.format("jdbc").option("url", "jdbc:mysql://database-1.cujgmw0ksjco.us-east-1.rds.amazonaws.com").option("driver", "org.mariadb.jdbc.Driver").option("dbtable", "trgdb.cctab").option("user", "root").option("password", "Root1234$").load()

jdbcDF1.printSchema()

jdbcDF1.count()

jdbcDF1.show()

jdbcDF2 = spark.read.jdbc("<RDS End Point>", "trgdb.tkttbl", properties={"user": "root", "password": "Root1234$"})

# For example:
# jdbcDF2 = spark.read.jdbc("jdbc:mysql://database-1.cujgmw0ksjco.us-east-1.rds.amazonaws.com/", "trgdb.tkttbl", properties={"user": "root", "password": "Root1234$"})

jdbcDF2.printSchema()

jdbcDF2.count()

jdbcDF2.show()
